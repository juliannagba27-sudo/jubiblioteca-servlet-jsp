package br.com.biblioteca.servlet;

import br.com.biblioteca.model.Livro;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/livro")
public class LivroServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Lista global em memória (thread-safe) enquanto a aplicação estiver ativa
    private static final List<Livro> livros = Collections.synchronizedList(new ArrayList<>());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String titulo = request.getParameter("titulo");
        String autor = request.getParameter("autor");
        String anoStr = request.getParameter("anoPublicacao");

        int ano = 0;
        try {
            ano = Integer.parseInt(anoStr);
        } catch (NumberFormatException e) {
            // Ignora e mantém 0 se não vier número válido
        }

        Livro novo = new Livro(titulo, autor, ano);
        livros.add(novo);

        // Redireciona para listagem
        response.sendRedirect(request.getContextPath() + "/livro?action=listar");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        if (action == null || action.isBlank() || action.equals("listar")) {
            request.setAttribute("livros", new ArrayList<>(livros));
        } else if ("buscar".equals(action)) {
            String q = request.getParameter("q");
            String needle = q == null ? "" : q.trim().toLowerCase();
            List<Livro> filtrados;
            synchronized (livros) {
                filtrados = livros.stream()
                        .filter(l -> l.getTitulo() != null && l.getTitulo().toLowerCase().contains(needle)
                                  || l.getAutor()  != null && l.getAutor().toLowerCase().contains(needle))
                        .collect(Collectors.toList());
            }
            request.setAttribute("livros", filtrados);
            request.setAttribute("q", q);
        }
        request.getRequestDispatcher("/lista.jsp").forward(request, response);
    }
}
