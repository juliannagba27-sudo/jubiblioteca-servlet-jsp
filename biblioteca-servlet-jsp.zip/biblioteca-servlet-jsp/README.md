# Biblioteca (Servlet + JSP, sem banco)

Sistema web simples para **cadastrar**, **listar** e **buscar** livros em memória, feito com **Jakarta Servlet/JSP** e executado com **Jetty** via Maven.

## Rodando no GitHub Codespaces (passo a passo)
1. Crie um repositório no GitHub (nome sugerido: `biblioteca-servlet-jsp`).
2. Faça upload de **todos os arquivos** deste projeto (ou envie o `.zip` e extraia no repositório).
3. Na página do repositório, clique no botão verde **Code** → **Create codespace on main**.
4. Quando o Codespaces abrir, abra o **Terminal** (menu `Terminal` → `New Terminal`).
5. No terminal, execute:
   ```bash
   mvn jetty:run
   ```
6. O Codespaces vai expor a **porta 8080**. Abra a aba **Ports** e clique em **Open in Browser** na linha da porta 8080.
7. O site abrirá em `/` (página de cadastro). Para listar/buscar, use o botão **Ver livros cadastrados** ou acesse `/livro?action=listar`.

### Parar o servidor
No terminal onde o Jetty está rodando, pressione `Ctrl + C`.

## Estrutura do projeto
```
src/
  main/
    java/
      br/com/biblioteca/model/Livro.java
      br/com/biblioteca/servlet/LivroServlet.java
    webapp/
      index.jsp
      lista.jsp
      WEB-INF/web.xml
pom.xml
```

## Tecnologias
- Java 17
- Jakarta Servlet 5.0 / JSP 3.0
- Maven + Jetty Maven Plugin (porta 8080)
